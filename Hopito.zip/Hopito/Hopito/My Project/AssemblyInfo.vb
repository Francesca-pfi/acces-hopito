﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' Les informations générales sur un assembly sont contrôlées via ce
' l’ensemble d’attributs suivant. Changez les valeurs de ces attributs pour modifier les informations
' associées à un assembly.

' Passez en revue les valeurs des attributs de l’assembly
<Assembly: AssemblyTitle("Hopito")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("")>
<Assembly: AssemblyProduct("Hopito")>
<Assembly: AssemblyCopyright("Copyright ©  2020")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

' Le GUID suivant est pour l’ID de la typelib si ce projet est exposé à COM
<Assembly: Guid("f2e20918-0c56-43da-a048-b9dd37a28fbf")>

' Les informations de version pour un assembly se composent des quatre valeurs suivantes :
'
'      Version principale
'      Version mineure
'      Numéro de build
'      Révision
'
' Vous pouvez spécifier toutes valeurs ou utiliser les valeurs Build et Révision par défaut
' en utilisant ’*’, comme indiqué ci-dessous :
' <Assembly: AssemblyVersion("1.0.*")>

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
